import React, { useState } from 'react';

const RecurringDate = () => {
  const [date, setDate] = useState('');
  const [frequency, setFrequency] = useState('daily');
  const [weekdays, setWeekdays] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const toggleWeekday = (day) => {
    if (weekdays.includes(day)) {
      setWeekdays(weekdays.filter(d => d !== day));
    } else {
      setWeekdays([...weekdays, day]);
    }
  };

  const handleSubmit = () => {
    setSubmitted(true);
  };

  return (
    <div style={{
      padding: '20px',
      border: '1px solid gray',
      borderRadius: '10px',
      maxWidth: '500px',
      margin: 'auto',
      marginTop: '30px',
      backgroundColor: '#f9f9f9'
    }}>
      <h2>📆 Select Recurring Date</h2>

      <input 
        type="date" 
        value={date} 
        onChange={(e) => setDate(e.target.value)} 
        style={{ marginBottom: '10px', display: 'block' }}
      />

      <label>
        Frequency: &nbsp;
        <select value={frequency} onChange={(e) => setFrequency(e.target.value)}>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
      </label>

      {frequency === 'weekly' && (
        <div style={{ marginTop: '15px' }}>
          <label><strong>Select weekdays:</strong></label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
            {allDays.map((day) => (
              <label key={day}>
                <input
                  type="checkbox"
                  checked={weekdays.includes(day)}
                  onChange={() => toggleWeekday(day)}
                />
                {day}
              </label>
            ))}
          </div>
        </div>
      )}

      <button 
        onClick={handleSubmit}
        style={{
          marginTop: '20px',
          padding: '10px 20px',
          backgroundColor: 'black',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer'
        }}
      >
        Submit
      </button>

      {submitted && (
        <div style={{
          marginTop: '20px',
          padding: '15px',
          border: '1px solid green',
          borderRadius: '8px',
          backgroundColor: '#f0fff0'
        }}>
          <h3>📅 Recurring Schedule Summary:</h3>
          <p><strong>Start Date:</strong> {date || 'Not selected'}</p>
          <p><strong>Frequency:</strong> {frequency}</p>
          {frequency === 'weekly' && (
            <p><strong>Selected Weekdays:</strong> {weekdays.length > 0 ? weekdays.join(', ') : 'None'}</p>
          )}
        </div>
      )}
    </div>
  );
};

export default RecurringDate;
