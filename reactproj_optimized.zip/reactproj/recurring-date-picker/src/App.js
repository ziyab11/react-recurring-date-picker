import React from 'react';
import RecurringDate from './Components/RecurringDate';

function App() {
  return (
    <div>
      <h1>Recurring Date Picker</h1>
      <RecurringDate />
    </div>
  );
}

export default App;
